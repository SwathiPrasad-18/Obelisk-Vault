from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.auth.routes import auth_router

app = FastAPI(title="Obelisk Vault Backend")

# Enable CORS for frontend
origins = ["*"]  # You can restrict this later to your domain
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(auth_router)

@app.get("/")
def home():
    return {"message": "Welcome to Obelisk Vault API"}
